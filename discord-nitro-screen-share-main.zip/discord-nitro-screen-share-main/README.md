![Image](https://i.imgur.com/c7XCSBv.png)

## Discord Nitro Screen Share Plugin

  * Plugin unlock 1080p  / SOURCE and 60fps screen share without discord nitro.


## How to Set up the Plugin

1. Download Better Discord and install.
2. Extract DNSS.plugin.js to %appdata%\BetterDiscord\Plugins (or ~/Library/Preferences/BetterDiscord/plugins for OSX)
3. Enable plugin in Better Discord.
5. Enjoy!
